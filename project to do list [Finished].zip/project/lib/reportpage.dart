import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:project/datClassProject.dart';

import 'datClassToDoList.dart';
import 'dbServices.dart';

class reportPage extends StatefulWidget {
  const reportPage({Key? key}) : super(key: key);

  @override
  State<reportPage> createState() => _reportPageState();
}

class _reportPageState extends State<reportPage> {
  Stream<QuerySnapshot<Object?>> getfinishedTDL() {
    setState(() {});
    return DatabaseToDoList.getfinishedTDL("selesai");
  }

  Stream<QuerySnapshot<Object?>> getfinishedProject() {
    setState(() {});
    return DatabaseProject.getFinishedProject("selesai");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text("History Page"),
      ),
      body: (Container(
        padding: EdgeInsets.all(8),
        child: Column(
          children: [
            const Text(
              "Project",
              style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.white),
            ),
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                  stream: getfinishedProject(),
                  builder: (context, snapshot) {
                    if (snapshot.hasError) {
                      return const Text('ERROR');
                    } else if (snapshot.hasData || snapshot.data != null) {
                      if (snapshot.data!.docs.length != 0) {
                        return ListView.separated(
                          itemBuilder: (context, index) {
                            DocumentSnapshot dsData =
                                snapshot.data!.docs[index];
                            String lvId = dsData['idProject'];
                            String lvNama = dsData['namaProject'];
                            String lvStatus = dsData['status'];

                            return ListTile(
                                onTap: () {
                                  final dtTDL = itemProject(
                                      itemIdProject: lvId,
                                      itemNamaProject: lvNama,
                                      itemStatusProject: lvStatus);
                                  setState(() {
                                    //EDIT status jadi : belum (belum kerjain...)
                                  });
                                },
                                onLongPress: () {
                                  DatabaseToDoList.hapusData(idPTL: lvId);
                                },
                                title: Column(
                                  children: [
                                    Row(
                                      children: [
                                        Text(
                                          lvNama,
                                          style: TextStyle(
                                              fontSize: 20,
                                              color: Colors.white,
                                              decoration:
                                                  TextDecoration.lineThrough),
                                        ),
                                      ],
                                    ),
                                    const Divider(
                                      thickness: 2,
                                      color: Colors.orange,
                                    ),
                                  ],
                                ));
                          },
                          separatorBuilder: (context, index) =>
                              SizedBox(height: 8.0),
                          itemCount: snapshot.data!.docs.length,
                        );
                      } else {
                        return const Center(
                          child: Text(
                            "No project has been done",
                            style: TextStyle(
                              fontSize: 16,
                              color: Colors.white,
                            ),
                          ),
                        );
                      }
                    }
                    return const Center(
                      child: CircularProgressIndicator(
                        valueColor: AlwaysStoppedAnimation<Color>(
                          Colors.pinkAccent,
                        ),
                      ),
                    );
                  }),
            ),
            const Text(
              "To Do List",
              style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.white),
            ),
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                stream: getfinishedTDL(),
                builder: (context, snapshot) {
                  if (snapshot.hasError) {
                    return const Text('ERROR');
                  } else if (snapshot.hasData || snapshot.data != null) {
                    if (snapshot.data!.docs.length != 0) {
                      return ListView.separated(
                        itemBuilder: (context, index) {
                          //mengambil data perindex ke dalam variabel dsData (read data)
                          DocumentSnapshot dsData = snapshot.data!.docs[index];
                          String lvIdProject = dsData['idProject'];
                          String lvIdTDL = dsData['idToDoList'];
                          String lvNamaTDL = dsData['namaToDoList'];
                          String lvStartDate = dsData['startDate'];
                          String lvEndDate = dsData['endDate'];
                          String lvStatus = "belum";
                          String changestatus = "belum";
                          // _jumlah = snapshot.data!.docs.length;
                          return ListTile(
                            onTap: () {
                              final dtTDL = itemToDoList(
                                  itemIdTDL: lvIdTDL,
                                  itemIdPTDL: lvIdProject,
                                  itemNamaTDL: lvNamaTDL,
                                  itemStartDateTDL: lvStartDate,
                                  itemEndDateTDL: lvEndDate,
                                  itemStatus: changestatus);
                              DatabaseToDoList.ubahDataTDL(item: dtTDL);
                            },
                            onLongPress: () {
                              // DatabaseToDoList.hapusData(idPTL: lvIdTDL);
                            },
                            title: Column(
                              children: [
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      lvNamaTDL,
                                      style: TextStyle(
                                          fontSize: 20,
                                          color: Colors.white,
                                          decoration:
                                              TextDecoration.lineThrough),
                                    ),
                                  ],
                                ),
                                const Divider(
                                  thickness: 2,
                                  color: Colors.orange,
                                ),
                              ],
                            ),
                          );
                        },
                        separatorBuilder: (context, index) =>
                            SizedBox(height: 8.0),
                        itemCount: snapshot.data!.docs.length,
                      );
                    } else {
                      return const Center(
                        child: Text(
                          "No to-do-list has been done",
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.white,
                          ),
                        ),
                      );
                    }
                  }
                  return const Center(
                    child: CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation<Color>(
                        Colors.pinkAccent,
                      ),
                    ),
                  );
                },
              ),
            ),
            ElevatedButton(
                onPressed: Navigator.of(context).pop,
                child: const Text("Back")),
          ],
        ),
      )),
    );
  }
}
