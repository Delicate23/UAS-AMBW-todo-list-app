// import 'package:firebase/dataclass.dart';
// import 'package:firebase/dbservices.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:project/datClassProject.dart';
import 'package:project/datClassToDoList.dart';
// import 'package:intl/project.dart';
// import 'package:project/dataclass.dart';
import 'package:project/dbServices.dart';

class detDataDTL extends StatefulWidget {
  //untuk data yang dikirim dari halaman main
  final itemToDoList? dataDetDTL;
  String statusDataDetDTL;
  detDataDTL({Key? key, this.dataDetDTL, required this.statusDataDetDTL})
      : super(key: key);

  @override
  State<detDataDTL> createState() => _detDataDTLState();
}

class _detDataDTLState extends State<detDataDTL> {
  final _ctrIdTDL = TextEditingController();
  final _ctrIdPTDL = TextEditingController();
  final _ctrNamaTDL = TextEditingController();
  final _ctrlStartTDL = TextEditingController();
  final _ctrlEndTDL = TextEditingController();
  final _ctrStatus = TextEditingController();
  TextEditingController dateinput = TextEditingController();

  bool _isDisabled = false;

  @override
  void dispose() {
    // TODO: implement dispose
    _ctrIdTDL.dispose();
    _ctrIdPTDL.dispose();
    _ctrNamaTDL.dispose();
    _ctrlStartTDL.dispose();
    _ctrlEndTDL.dispose();
    _ctrStatus.dispose();
    super.dispose();
  }

  DateTime selectedDate = DateTime.now();

  _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate, // Refer step 1
      firstDate: DateTime(2000),
      lastDate: DateTime(2025),
    );
    if (picked != null && picked != selectedDate)
      setState(() {
        selectedDate = picked;
      });
  }

  @override
  void initState() {
    // TODO: implement initState
    _ctrIdTDL.text = widget.dataDetDTL?.itemIdTDL ?? "";
    _ctrIdPTDL.text = widget.dataDetDTL?.itemIdPTDL ?? "";
    _ctrNamaTDL.text = widget.dataDetDTL?.itemNamaTDL ?? "";
    _ctrlStartTDL.text = widget.dataDetDTL?.itemStartDateTDL ?? "";
    _ctrlEndTDL.text = widget.dataDetDTL?.itemEndDateTDL ?? "";
    _ctrStatus.text = widget.dataDetDTL?.itemStatus ?? "";
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.statusDataDetDTL == "edit") {
      _isDisabled = true;
    }
    return Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          title: Text('Detail Data Note'),
        ),
        body: SingleChildScrollView(
          child: Container(
            margin: EdgeInsets.all(16.0),
            child: Expanded(
              child: Column(
                children: [
                  Text(
                    "Data To Do List",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 25,
                        fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 20),
                  TextField(
                    controller: _ctrIdTDL,
                    enabled: _isDisabled,
                    readOnly: true,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'ID TDL',
                      labelStyle: TextStyle(
                          color: Colors.orange[500],
                          fontWeight: FontWeight.bold,
                          fontSize: 25),
                      filled: true,
                      fillColor: Color.fromARGB(255, 92, 92, 92),
                    ),
                    style: TextStyle(fontSize: 20, color: Colors.white),
                  ),
                  SizedBox(
                    height: 15.0,
                  ),
                  TextField(
                    controller: _ctrIdPTDL,
                    enabled: _isDisabled,
                    readOnly: true,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'ID Project',
                      labelStyle: TextStyle(
                          color: Colors.orange[500],
                          fontWeight: FontWeight.bold,
                          fontSize: 25),
                      filled: true,
                      fillColor: Color.fromARGB(255, 92, 92, 92),
                    ),
                    style: TextStyle(fontSize: 20, color: Colors.white),
                  ),
                  SizedBox(
                    height: 15.0,
                  ),
                  TextField(
                    controller: _ctrNamaTDL,
                    enabled: _isDisabled,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Nama TDL',
                      labelStyle: TextStyle(
                          color: Colors.orange[500],
                          fontWeight: FontWeight.bold,
                          fontSize: 25),
                      filled: true,
                      fillColor: Color.fromARGB(255, 92, 92, 92),
                    ),
                    style: TextStyle(fontSize: 20, color: Colors.white),
                  ),
                  SizedBox(
                    height: 15.0,
                  ),
                  TextField(
                    controller: _ctrlStartTDL,
                    enabled: _isDisabled,
                    readOnly: true,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Start Date',
                      labelStyle: TextStyle(
                          color: Colors.orange[500],
                          fontWeight: FontWeight.bold,
                          fontSize: 25),
                      filled: true,
                      fillColor: Color.fromARGB(255, 92, 92, 92),
                    ),
                    style: TextStyle(fontSize: 20, color: Colors.white),
                    onTap: () async {
                      DateTime? pickedDate = await showDatePicker(
                          context: context,
                          initialDate: DateTime.now(),
                          firstDate: DateTime(2000),
                          lastDate: DateTime(2101));

                      if (pickedDate != null) {
                        print(pickedDate);
                        String formattedDate =
                            DateFormat('yyyy-MM-dd').format(pickedDate);
                        print(formattedDate);

                        setState(() {
                          _ctrlStartTDL.text = formattedDate;
                        });
                      } else {
                        print("Date is not selected");
                      }
                    },
                  ),

                  SizedBox(
                    height: 15.0,
                  ),
                  TextField(
                    controller: _ctrlEndTDL,
                    enabled: _isDisabled,
                    readOnly: true,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'End Date',
                      labelStyle: TextStyle(
                          color: Colors.orange[500],
                          fontWeight: FontWeight.bold,
                          fontSize: 25),
                      filled: true,
                      fillColor: Color.fromARGB(255, 92, 92, 92),
                    ),
                    style: TextStyle(fontSize: 20, color: Colors.white),
                    onTap: () async {
                      DateTime? pickedDate = await showDatePicker(
                          context: context,
                          initialDate: DateTime.now(),
                          firstDate: DateTime(2000),
                          lastDate: DateTime(2101));

                      if (pickedDate != null) {
                        print(pickedDate);
                        String formattedDate =
                            DateFormat('yyyy-MM-dd').format(pickedDate);
                        print(formattedDate);

                        setState(() {
                          _ctrlEndTDL.text = formattedDate;
                        });
                      } else {
                        print("Date is not selected");
                      }
                    },
                  ),
                  SizedBox(
                    height: 15.0,
                  ),
                  TextField(
                    controller: _ctrStatus,
                    enabled: _isDisabled,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Status',
                      labelStyle: TextStyle(
                          color: Colors.orange[500],
                          fontWeight: FontWeight.bold,
                          fontSize: 25),
                      filled: true,
                      fillColor: Color.fromARGB(255, 92, 92, 92),
                    ),
                    style: TextStyle(fontSize: 20, color: Colors.white),
                  ),

                  SizedBox(
                    height: 20.0,
                  ),

                  Container(
                    alignment: Alignment.center,
                    child: ElevatedButton(
                      onPressed: Navigator.of(context).pop,
                      child: Text("BACK"),
                    ),
                  ),
                  // style: TextStyle(fontSize: 20, color: Colors.white),

                  ElevatedButton(
                    onPressed: () {
                      final dt = itemToDoList(
                          itemIdTDL: _ctrIdTDL.text,
                          itemIdPTDL: _ctrIdPTDL.text,
                          itemNamaTDL: _ctrNamaTDL.text,
                          itemStartDateTDL: _ctrlStartTDL.text,
                          itemEndDateTDL: _ctrlEndTDL.text,
                          itemStatus: _ctrStatus.text);
                      DatabaseToDoList.ubahDataTDL(item: dt);
                      Navigator.pop(context);
                    },
                    child: Text('Simpan Data'),
                  ),
                ],
              ),
            ),
          ),
        ));
  }
}
