import 'package:flutter/gestures.dart';

class itemProject {
  final itemIdProject;
  final itemNamaProject;
  final itemStatusProject;

  itemProject(
      {required this.itemIdProject,
      required this.itemNamaProject,
      required this.itemStatusProject});

  //ke json
  Map<String, dynamic> toJson() {
    return {
      "idProject": itemIdProject,
      "namaProject": itemNamaProject,
      "status": itemStatusProject
    };
  }

  //json ke dataclass
  factory itemProject.fromJson(Map<String, dynamic> json) {
    return itemProject(
        itemIdProject: json['idProject'],
        itemNamaProject: json['namaProject'],
        itemStatusProject: json['status']);
  }
}
