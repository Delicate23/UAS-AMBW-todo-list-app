class itemToDoList {
  final itemIdTDL;
  final itemIdPTDL;
  final itemNamaTDL;
  final itemStartDateTDL;
  final itemEndDateTDL;
  final itemStatus;

  itemToDoList(
      {required this.itemIdTDL,
      required this.itemIdPTDL,
      required this.itemNamaTDL,
      required this.itemStartDateTDL,
      required this.itemEndDateTDL,
      required this.itemStatus});

  Map<String, dynamic> toJson() {
    return {
      "idToDoList": itemIdTDL,
      "idProject": itemIdPTDL,
      "namaToDoList": itemNamaTDL,
      "startDate": itemStartDateTDL,
      "endDate": itemEndDateTDL,
      "status": itemStatus
    };
  }

  factory itemToDoList.fromJson(Map<String, dynamic> json) {
    return itemToDoList(
        itemIdTDL: json['idToDoList'],
        itemIdPTDL: json['idProject'],
        itemNamaTDL: json['namaToDoList'],
        itemStartDateTDL: json['startDate'],
        itemEndDateTDL: json['endDate'],
        itemStatus: json['status']);
  }
}
