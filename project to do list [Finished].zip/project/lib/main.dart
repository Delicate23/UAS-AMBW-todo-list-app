import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:project/addDataTDL.dart';
import 'package:project/addProject.dart';
import 'package:project/datClassProject.dart';
import 'package:project/datClassToDoList.dart';
import 'package:project/detdata.dart';
import 'package:project/detdataTDL.dart';
import 'package:badges/badges.dart';
// import 'badges.dart'
import 'package:project/missingpage.dart';
import 'package:project/reportpage.dart';

import 'firebase_options.dart';
import 'dbServices.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  runApp(
    MaterialApp(
      title: "HOME",
      home: MyApp(),
    ),
  );
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  final _searchText = TextEditingController();
  int? _jumlahBelumSelesai;
  int _count = 0;
  bool tdlProject = false;
  @override
  void initState() {
    // _count = 0;
    _jumlahBelumSelesai = 0;
    setState(() {
      badgeproject();
      badgetdl();
    });

    // TODO: implement initState
    super.initState();
  }

  @override
  void dispose() {
    _searchText.dispose();
    super.dispose();
  }

  @override
  void initStateProject() {
    _searchText.addListener(onSearchProject);
    super.initState();
  }

  Stream<QuerySnapshot<Object?>> onSearchProject() {
    setState(() {});
    return DatabaseProject.getDataProject();
  }

  @override
  void initStateTDL() {
    _searchText.addListener(onSearchTDL);
    super.initState();
  }

  Stream<QuerySnapshot<Object?>> onSearchTDL() {
    setState(() {});
    return DatabaseToDoList.getDataTDL();
  }

  Stream<QuerySnapshot<Object?>> getDataTDLProject(String id) {
    setState(() {});
    return DatabaseToDoList.getDataTDLProject(id);
  }

  // Stream<QuerySnapshot<Object?>> onSearchTDLProject() {
  //   setState(() {});
  //   return
  // }

  String? a;
  void getlastid() {
    CToDoList.get().then((QuerySnapshot snapshot) {
      snapshot.docs.forEach((doc) {
        a = doc["idToDoList"];
      });
    });
  }

  void badgeproject() async {
    setState(() {
      Cproject.where("status", isEqualTo: "telat")
          .get()
          .then((QuerySnapshot snapshot) {
        snapshot.docs.forEach((doc) {
          _count = _count + 1;
          print(_count.toString() + "proooiki lho he");
        });
        print(_count.toString() + "proooiki lho he1");
      });
      print(_count.toString());
    });
  }

  void badgetdl() async {
    setState(() {
      CToDoList.where("status", isEqualTo: "telat")
          .where("idProject", isEqualTo: "0")
          .get()
          .then((QuerySnapshot snapshot) {
        snapshot.docs.forEach((doc) {
          _count = _count + 1;
          print(_count.toString() + "iki lho he1");
        });
        print(_count.toString() + "iki lho he");
      });
    });
  }

  void deletetdlproject(String idprojek) {
    CToDoList.where("idProject", isEqualTo: idprojek)
        .get()
        .then((QuerySnapshot snapshot) {
      snapshot.docs.forEach((doc) {
        DatabaseToDoList.hapusData(idPTL: doc["idToDoList"]);
      });
    });
  }

  int _lastProject = 0;
  int _lastItem = 0;
  int _id = 0;
  @override
  Widget build(BuildContext context) {
    setState(() {
      badgeproject();
      badgetdl();
    });

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text("FIREBASE CRUD"),
      ),
      body: Container(
        // padding: EdgeInsets.all(8.0),
        margin: EdgeInsets.fromLTRB(8, 20, 8, 8),
        child: Column(
          children: [
            // TextField(
            //   controller: _searchText,
            //   decoration: InputDecoration(
            //       prefixIcon: Icon(Icons.search),
            //       border: OutlineInputBorder(
            //         borderRadius: BorderRadius.circular(10),
            //         borderSide: BorderSide(color: Colors.blue),
            //       )),
            // ),

            Container(
              alignment: Alignment.centerLeft,
              child: Row(
                children: [
                  // SizedBox(
                  //   child: Builder(
                  //     builder: (contextt) {
                  //       return ElevatedButton(
                  //         onPressed: () {
                  //           // buttonPressed("=");
                  //           // listHistory.add(hasil_akhir.toString());
                  //           Navigator.push(
                  //             contextt,
                  //             MaterialPageRoute(
                  //               builder: (context) {
                  //                 return detData(
                  //                   statusDataDet: "isi",
                  //                 );
                  //               },
                  //             ),
                  //           );
                  //         },
                  //         child: Icon(Icons.flag),
                  //         style: ElevatedButton.styleFrom(
                  //           primary: Colors.red,
                  //           onPrimary: Colors.white,
                  //           textStyle: TextStyle(
                  //               color: Colors.black,
                  //               fontSize: 15,
                  //               fontStyle: FontStyle.italic),
                  //         ),
                  //       );
                  //     },
                  //   ),
                  // ),
                  ElevatedButton(
                      //to report page
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) {
                              return reportPage();
                            },
                          ),
                        );
                      },
                      child: Icon(Icons.bar_chart),
                      style: ElevatedButton.styleFrom(
                        primary: Colors.black,
                      )),
                  Badge(
                    //to missing page
                    child: ElevatedButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) {
                                return missingPage();
                              },
                            ),
                          );
                        },
                        child: Icon(Icons.report),
                        style: ElevatedButton.styleFrom(
                          primary: Colors.black,
                        )),
                    badgeContent: Text(_count.toString()),
                  )
                ],
              ),
            ),

            // SizedBox(height: 10),

            //DEMO: PROJECT
            Text(
              "Project",
              style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.white),
            ),
            Container(
              alignment: Alignment.centerRight,
              child: SizedBox(
                width: 100.0,
                height: 25.0,
                child: Builder(
                  builder: (contextt) {
                    return ElevatedButton(
                      onPressed: () {
                        // buttonPressed("=");
                        // listHistory.add(hasil_akhir.toString());
                        Navigator.push(
                          contextt,
                          MaterialPageRoute(
                            builder: (context) {
                              return addData(
                                lastItem: _lastItem,
                                lastProject: _lastProject,
                              );
                            },
                          ),
                        );
                      },
                      child: Text("Project"),
                      style: ElevatedButton.styleFrom(
                        primary: Colors.orange,
                        onPrimary: Colors.white,
                        textStyle: TextStyle(
                            color: Colors.black,
                            fontSize: 20,
                            fontStyle: FontStyle.italic),
                      ),
                    );
                  },
                ),
              ),
            ),
            SizedBox(height: 10),
            Container(
              child: Expanded(
                child: StreamBuilder<QuerySnapshot>(
                  // stream: Database.getData(),
                  stream: onSearchProject(),
                  builder: (context, snapshot) {
                    if (snapshot.hasError) {
                      return const Text('ERROR');
                    } else if (snapshot.hasData || snapshot.data != null) {
                      return ListView.separated(
                        itemBuilder: (context, index) {
                          //mengambil data perindex ke dalam variabel dsData (read data)
                          DocumentSnapshot dsData = snapshot.data!.docs[index];
                          String lvId = dsData['idProject'];
                          String lvNama = dsData['namaProject'];
                          String lvStatus = dsData['status'];
                          if (int.parse(lvId) > _lastProject) {
                            _lastProject = int.parse(lvId);
                          }
                          if (lvStatus != "selesai" && lvStatus != "telat") {
                            return ListTile(
                              onTap: () {
                                final dtProject = itemProject(
                                    itemIdProject: lvId,
                                    itemNamaProject: lvNama,
                                    itemStatusProject: lvStatus);
                                setState(() {
                                  tdlProject = true;
                                  _id = int.parse(lvId);
                                  print("tdlproject: $tdlProject + id: $_id");
                                });
                                // Database.ubahData(item: dtBaru);
                                // Navigator.push(
                                //   context,
                                //   MaterialPageRoute(
                                //       builder: (context) => detData(
                                //             dataDet: dtProject,
                                //             statusDataDet: "isi",
                                //             lastItem: _lastItem,
                                //           )),
                                // );
                              },
                              onLongPress: () {
                                final dtProject = itemProject(
                                    itemIdProject: lvId,
                                    itemNamaProject: lvNama,
                                    itemStatusProject: "selesai");
                                DatabaseProject.ubahDataProject(
                                    item: dtProject);
                                deletetdlproject(lvId);
                                _lastItem = 0;
                                ScaffoldMessenger.of(context).showSnackBar(
                                  //snackbar digunakan untuk memunculkan notif pada saat dipencet isi dari listviewnya
                                  SnackBar(
                                    //indexnya dari itemBuilder atas itu
                                    content: Text("Project has been deleted"),
                                  ),
                                );
                              },
                              title: Column(
                                children: [
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        lvNama,
                                        style: TextStyle(
                                            fontSize: 20, color: Colors.white),
                                      ),
                                      Row(
                                        children: [
                                          Container(
                                            child: SizedBox(
                                              width: 55.0,
                                              height: 25.0,
                                              child: Builder(
                                                builder: (contextt) {
                                                  return ElevatedButton(
                                                    onPressed: () {
                                                      final dtProject =
                                                          itemProject(
                                                              itemIdProject:
                                                                  lvId,
                                                              itemNamaProject:
                                                                  lvNama,
                                                              itemStatusProject:
                                                                  lvStatus);
                                                      // buttonPressed("=");
                                                      // listHistory.add(hasil_akhir.toString());
                                                      Navigator.push(
                                                        contextt,
                                                        MaterialPageRoute(
                                                          builder: (context) =>
                                                              detData(
                                                            dataDet: dtProject,
                                                            statusDataDet:
                                                                "edit",
                                                            lastItem: _lastItem,
                                                          ),
                                                        ),
                                                      );
                                                    },
                                                    child: Icon(Icons.edit),
                                                    style: ElevatedButton
                                                        .styleFrom(
                                                      primary: Colors.black,
                                                      onPrimary: Colors.grey,
                                                      textStyle: TextStyle(
                                                          color: Colors.black,
                                                          fontSize: 20,
                                                          fontStyle:
                                                              FontStyle.italic),
                                                    ),
                                                  );
                                                },
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                  const Divider(
                                    thickness: 2,
                                    color: Colors.orange,
                                  ),
                                ],
                              ),
                            );
                          } else {
                            return SizedBox(height: 0);
                          }
                        },
                        separatorBuilder: (context, index) =>
                            SizedBox(height: 0.0),
                        itemCount: snapshot.data!.docs.length,
                      );
                    }
                    return const Center(
                      child: CircularProgressIndicator(
                        valueColor: AlwaysStoppedAnimation<Color>(
                          Colors.pinkAccent,
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),

            SizedBox(height: 10),

            //DEMO: TO DO LIST
            Text(
              "To Do List",
              style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.white),
            ),
            Container(
              alignment: Alignment.centerRight,
              child: SizedBox(
                width: 100.0,
                height: 25.0,
                child: Builder(
                  builder: (contextt) {
                    return ElevatedButton(
                      onPressed: () {
                        // buttonPressed("=");
                        // listHistory.add(hasil_akhir.toString());
                        Navigator.push(
                          contextt,
                          MaterialPageRoute(
                            builder: (context) {
                              return addDataDTL(
                                idProject: 0,
                                lastItem: _lastItem,
                              );
                            },
                          ),
                        );
                      },
                      child: Text("TDL"),
                      style: ElevatedButton.styleFrom(
                        primary: Colors.orange,
                        onPrimary: Colors.white,
                        textStyle: TextStyle(
                            color: Colors.black,
                            fontSize: 20,
                            fontStyle: FontStyle.italic),
                      ),
                    );
                  },
                ),
              ),
            ),
            SizedBox(height: 10),
            Container(
              child: Expanded(
                child: StreamBuilder<QuerySnapshot>(
                  //stream: DatabaseToDoList.getDataTDL(),
                  stream: tdlProject
                      ? getDataTDLProject(_id.toString())
                      : onSearchTDL(),
                  builder: (context, snapshot) {
                    if (snapshot.hasError) {
                      return const Text('ERROR');
                    } else if (snapshot.hasData || snapshot.data != null) {
                      return ListView.separated(
                        itemBuilder: (context, index) {
                          //mengambil data perindex ke dalam variabel dsData (read data)
                          DocumentSnapshot dsData = snapshot.data!.docs[index];
                          // String lvId = dsData['idProject'];
                          // String lvNama = dsData['namaProject'];
                          String lvIdProject = dsData['idProject'];
                          String lvIdTDL = dsData['idToDoList'];
                          String lvNamaTDL = dsData['namaToDoList'];
                          String lvStartDate = dsData['startDate'];
                          String lvEndDate = dsData['endDate'];
                          String lvStatus = dsData['status'];
                          if (int.parse(lvIdTDL) > _lastItem) {
                            _lastItem = int.parse(lvIdTDL);
                          }
                          if (lvIdProject == "0" ||
                              lvStatus != "selesai" && lvStatus != "telat") {
                            return ListTile(
                              onTap: () {
                                final dtTDL = itemToDoList(
                                    itemIdTDL: lvIdTDL,
                                    itemIdPTDL: lvIdProject,
                                    itemNamaTDL: lvNamaTDL,
                                    itemStartDateTDL: lvStartDate,
                                    itemEndDateTDL: lvEndDate,
                                    itemStatus: lvStatus);
                                // setState(() {
                                //   tdlProject = true;
                                //   _id = int.parse(lvIdProject);
                                //   print("tdlproject: $tdlProject + id: $_id");
                                // });

                                // Database.ubahData(item: dtBaru);
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => detDataDTL(
                                            dataDetDTL: dtTDL,
                                            statusDataDetDTL: "isi",
                                          )),
                                );
                              },
                              onLongPress: () {
                                final dtTDL = itemToDoList(
                                    itemIdTDL: lvIdTDL,
                                    itemIdPTDL: lvIdProject,
                                    itemNamaTDL: lvNamaTDL,
                                    itemStartDateTDL: lvStartDate,
                                    itemEndDateTDL: lvEndDate,
                                    itemStatus: "selesai");
                                DatabaseToDoList.ubahDataTDL(item: dtTDL);
                                ScaffoldMessenger.of(context).showSnackBar(
                                  //snackbar digunakan untuk memunculkan notif pada saat dipencet isi dari listviewnya
                                  SnackBar(
                                    //indexnya dari itemBuilder atas itu
                                    content: Text("1 ToDoList Done"),
                                  ),
                                );
                              },
                              title: Column(
                                children: [
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        lvNamaTDL,
                                        style: TextStyle(
                                            fontSize: 20, color: Colors.white),
                                      ),
                                      Row(
                                        children: [
                                          Container(
                                            child: SizedBox(
                                              width: 55.0,
                                              height: 25.0,
                                              child: Builder(
                                                builder: (context) {
                                                  return ElevatedButton(
                                                    onPressed: () {
                                                      final dtToDoList =
                                                          itemToDoList(
                                                              itemIdTDL:
                                                                  lvIdTDL,
                                                              itemIdPTDL:
                                                                  lvIdProject,
                                                              itemNamaTDL:
                                                                  lvNamaTDL,
                                                              itemStartDateTDL:
                                                                  lvStartDate,
                                                              itemEndDateTDL:
                                                                  lvEndDate,
                                                              itemStatus:
                                                                  lvStatus);
                                                      // buttonPressed("=");
                                                      // listHistory.add(hasil_akhir.toString());
                                                      Navigator.push(
                                                        context,
                                                        MaterialPageRoute(
                                                          builder: (context) =>
                                                              detDataDTL(
                                                            dataDetDTL:
                                                                dtToDoList,
                                                            statusDataDetDTL:
                                                                "edit",
                                                          ),
                                                        ),
                                                      );
                                                    },
                                                    child: Icon(Icons.edit),
                                                    style: ElevatedButton
                                                        .styleFrom(
                                                      primary: Colors.black,
                                                      onPrimary: Colors.grey,
                                                      textStyle: TextStyle(
                                                          color: Colors.black,
                                                          fontSize: 20,
                                                          fontStyle:
                                                              FontStyle.italic),
                                                    ),
                                                  );
                                                },
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                  const Divider(
                                    thickness: 2,
                                    color: Colors.orange,
                                  ),
                                ],
                              ),

                              // subtitle: Text(
                              //   lvNamaTDL,
                              //   style: TextStyle(fontSize: 15),
                              // ),
                            );
                          } else {
                            print("babi");
                            return SizedBox(height: 0);
                          }
                        },
                        separatorBuilder: (context, index) =>
                            SizedBox(height: 0.0),
                        itemCount: snapshot.data!.docs.length,
                      );
                    }
                    return const Center(
                      child: CircularProgressIndicator(
                        valueColor: AlwaysStoppedAnimation<Color>(
                          Colors.pinkAccent,
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
