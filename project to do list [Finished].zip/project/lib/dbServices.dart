// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:project/datClassProject.dart';

// CollectionReference Cproject = FirebaseFirestore.instance.collection("project");

// class Database {
//   static Stream<QuerySnapshot> getData() {
//     return Cproject.snapshots();
//   }
// }

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:project/datClassProject.dart';
import 'package:project/datClassToDoList.dart';

CollectionReference Cproject = FirebaseFirestore.instance.collection("project");
CollectionReference CToDoList =
    FirebaseFirestore.instance.collection("toDoList");

// class Database {
//   static Stream<QuerySnapshot> getData() {
//     return Cproject.snapshots();
//   }
// }

class DatabaseProject {
  // ambil data Project
  static Stream<QuerySnapshot> getDataProject() {
    return Cproject.snapshots();
  }

  static Stream<QuerySnapshot> getFinishedProject(String mode) {
    return Cproject.where("status", isEqualTo: mode).snapshots();
  }

  static int getUnfinishedProjectCount() {
    if (Cproject.where("endDate", isLessThan: DateTime.now())
            .snapshots()
            .length ==
        null) {
      return 0;
    } else {
      return int.parse(Cproject.where("endDate", isLessThan: DateTime.now())
          .snapshots()
          .length
          .toString());
    }
  }

  // tambah data
  static Future<void> tambahDataProject({required itemProject item}) async {
    DocumentReference docRef = Cproject.doc(item.itemIdProject);
    await docRef
        .set(item.toJson())
        .whenComplete(() => print("data berhasil diinput"))
        .catchError((e) => print(e));
  }

  // update data
  // static Future<void> ubahData({required itemProject item}) async {
  //   DocumentReference docRef = Cproject.doc(item.itemIdProject);
  //   await docRef
  //       .update(item.toJson())
  //       .whenComplete(() => print("data berhasil diubah"))
  //       .catchError((e) => print(e));
  // }

  static Future<void> hapusData({required String judulhapus}) async {
    DocumentReference docRef = Cproject.doc(judulhapus);

    await docRef
        .delete()
        .whenComplete(() => print("data berhasil dihapus"))
        .catchError((e) => print(e));
  }

  static Future<void> ubahDataProject({required itemProject item}) async {
    //untuk mengambil dokumen mana yang ingin kita rubah datanya
    DocumentReference docRef = Cproject.doc(item.itemIdProject);

    await docRef
        .update(item.toJson())
        .whenComplete(() => "data berhasil di ubah")
        .catchError((e) => print(e));
  }
}

class DatabaseToDoList {
  //ambil data To Do List
  static Stream<QuerySnapshot> getDataTDL() {
    return CToDoList.snapshots();
  }

  static Stream<QuerySnapshot> getfinishedTDL(String mode) {
    return CToDoList.where("status", isEqualTo: mode).snapshots();
  }

  static Future<int> countunfinishedTDL() async {
    //rens
    QuerySnapshot _count =
        await CToDoList.where("endDate", isLessThan: DateTime.now()).get();
    List<DocumentSnapshot> _myDocCount = _count.docs;
    return _myDocCount.length;
  }

  static Stream<QuerySnapshot> getDataTDLProject(String id) {
    return CToDoList.orderBy("idProject")
        .startAt([id]).endAt([id + '\uf8ff']).snapshots();
    // return CToDoList.snapshots();
  }

  static Future<void> tambahDataTDL({required itemToDoList item}) async {
    DocumentReference docRef = CToDoList.doc(item.itemIdTDL);

    await docRef
        .set(item.toJson())
        .whenComplete(() => print("data berhasil diinput"))
        .catchError((e) => print(e));
  }

  static Future<void> hapusData({required String idPTL}) async {
    DocumentReference docRef = CToDoList.doc(idPTL);

    await docRef
        .delete()
        .whenComplete(() => print("data berhasil dihapus"))
        .catchError((e) => print(e));
  }

  static Future<void> ubahDataTDL({required itemToDoList item}) async {
    //untuk mengambil dokumen mana yang ingin kita rubah datanya
    DocumentReference docRef = CToDoList.doc(item.itemIdTDL);

    await docRef
        .update(item.toJson())
        .whenComplete(() => "data berhasil di ubah")
        .catchError((e) => print(e));
  }
}
