// import 'package:firebase/dataclass.dart';
// import 'package:firebase/dbservices.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import 'package:project/datClassProject.dart';
import 'package:project/datClassToDoList.dart';

// import 'package:project/dataclass.dart';
import 'package:project/dbServices.dart';

class addDataDTL extends StatefulWidget {
  //untuk data yang dikirim dari halaman main
  int idProject = 0;
  int lastItem = 0;
  addDataDTL({Key? key, required this.lastItem, required this.idProject})
      : super(key: key);

  @override
  State<addDataDTL> createState() => _addDataDTLState();
}

class _addDataDTLState extends State<addDataDTL> {
  final _ctrIdPTDL = TextEditingController();
  final _ctrNamaTDL = TextEditingController();
  final _ctrlStartTDL = TextEditingController();
  final _ctrlEndTDL = TextEditingController();
  final _ctrStatus = TextEditingController();
  int length = 0;
  TextEditingController dateinput = TextEditingController();

  bool _isDisabled = true;

  @override
  void dispose() {
    // TODO: implement dispose
    _ctrIdPTDL.dispose();
    _ctrNamaTDL.dispose();
    _ctrlStartTDL.dispose();
    _ctrlEndTDL.dispose();
    _ctrStatus.dispose();
    super.dispose();
  }

  DateTime selectedDate = DateTime.now();

  _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate, // Refer step 1
      firstDate: DateTime(2000),
      lastDate: DateTime(2025),
    );
    if (picked != null && picked != selectedDate)
      setState(() {
        selectedDate = picked;
      });
  }

  @override
  void initState() {
    // TODO: implement initState
    _ctrIdPTDL.text = widget.idProject.toString();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          title: Text('Detail Data Note'),
        ),
        body: SingleChildScrollView(
          child: Container(
            margin: EdgeInsets.all(16.0),
            child: Expanded(
              child: Column(
                children: [
                  Text(
                    "Data To Do List",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 25,
                        fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 20),
                  TextField(
                    controller: _ctrNamaTDL,
                    enabled: _isDisabled,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Nama TDL',
                      labelStyle: TextStyle(
                          color: Colors.orange[500],
                          fontWeight: FontWeight.bold,
                          fontSize: 25),
                      filled: true,
                      fillColor: Color.fromARGB(255, 92, 92, 92),
                    ),
                    style: TextStyle(fontSize: 20, color: Colors.white),
                  ),
                  SizedBox(
                    height: 15.0,
                  ),
                  TextField(
                    controller: _ctrlStartTDL,
                    enabled: _isDisabled,
                    readOnly: true,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Start Date',
                      labelStyle: TextStyle(
                          color: Colors.orange[500],
                          fontWeight: FontWeight.bold,
                          fontSize: 25),
                      filled: true,
                      fillColor: Color.fromARGB(255, 92, 92, 92),
                    ),
                    style: TextStyle(fontSize: 20, color: Colors.white),
                    onTap: () async {
                      DateTime? pickedDate = await showDatePicker(
                          context: context,
                          initialDate: DateTime.now(),
                          firstDate: DateTime(
                              2000), //DateTime.now() - not to allow to choose before today.
                          lastDate: DateTime(2101));

                      if (pickedDate != null) {
                        print(
                            pickedDate); //pickedDate output format => 2021-03-10 00:00:00.000
                        String formattedDate =
                            DateFormat('yyyy-MM-dd').format(pickedDate);
                        print(
                            formattedDate); //formatted date output using intl package =>  2021-03-16
                        //you can implement different kind of Date Format here according to your requirement

                        setState(() {
                          _ctrlStartTDL.text =
                              formattedDate; //set output date to TextField value.
                        });
                      } else {
                        print("Date is not selected");
                      }
                    },
                  ),

                  SizedBox(
                    height: 15.0,
                  ),
                  TextField(
                    controller: _ctrlEndTDL,
                    enabled: _isDisabled,
                    readOnly: true,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'End Date',
                      labelStyle: TextStyle(
                          color: Colors.orange[500],
                          fontWeight: FontWeight.bold,
                          fontSize: 25),
                      filled: true,
                      fillColor: Color.fromARGB(255, 92, 92, 92),
                    ),
                    style: TextStyle(fontSize: 20, color: Colors.white),
                    onTap: () async {
                      DateTime? pickedDate = await showDatePicker(
                          context: context,
                          initialDate: DateTime.now(),
                          firstDate: DateTime(
                              2000), //DateTime.now() - not to allow to choose before today.
                          lastDate: DateTime(2101));

                      if (pickedDate != null) {
                        print(
                            pickedDate); //pickedDate output format => 2021-03-10 00:00:00.000
                        String formattedDate =
                            DateFormat('yyyy-MM-dd').format(pickedDate);
                        print(
                            formattedDate); //formatted date output using intl package =>  2021-03-16
                        //you can implement different kind of Date Format here according to your requirement

                        setState(() {
                          _ctrlEndTDL.text =
                              formattedDate; //set output date to TextField value.
                        });
                      } else {
                        print("Date is not selected");
                      }
                    },
                  ),
                  SizedBox(
                    height: 15.0,
                  ),
                  // TextField(
                  //   controller: _ctrStatus,
                  //   enabled: _isDisabled,
                  //   decoration: InputDecoration(
                  //     border: OutlineInputBorder(),
                  //     labelText: 'Status',
                  //     labelStyle: TextStyle(
                  //         color: Colors.orange[500],
                  //         fontWeight: FontWeight.bold,
                  //         fontSize: 25),
                  //     filled: true,
                  //     fillColor: Color.fromARGB(255, 92, 92, 92),
                  //   ),
                  //   style: TextStyle(fontSize: 20, color: Colors.white),
                  // ),

                  SizedBox(
                    height: 20.0,
                  ),

                  Container(
                    alignment: Alignment.center,
                    child: ElevatedButton(
                      onPressed: Navigator.of(context).pop,
                      child: Text("BACK"),
                    ),
                  ),
                  // style: TextStyle(fontSize: 20, color: Colors.white),

                  ElevatedButton(
                    onPressed: () {
                      final dt = itemToDoList(
                        itemIdTDL: (widget.lastItem + 1).toString(),
                        itemIdPTDL: widget.idProject.toString(),
                        itemNamaTDL: _ctrNamaTDL.text,
                        itemStartDateTDL: _ctrlStartTDL.text,
                        itemEndDateTDL: _ctrlEndTDL.text,
                        itemStatus: "belum",
                        // itemStatus: _ctrStatus.text
                      );
                      DatabaseToDoList.tambahDataTDL(item: dt);
                      ScaffoldMessenger.of(context).showSnackBar(
                        //snackbar digunakan untuk memunculkan notif pada saat dipencet isi dari listviewnya
                        SnackBar(
                          //indexnya dari itemBuilder atas itu
                          content: Text("ToDoList Added Successfully"),
                        ),
                      );
                      Navigator.pop(context);
                    },
                    child: Text('Simpan Data'),
                  ),
                ],
              ),
            ),
          ),
        ));
  }
}
