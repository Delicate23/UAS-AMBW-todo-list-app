// import 'package:firebase/dataclass.dart';
// import 'package:firebase/dbservices.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:project/datClassProject.dart';
import 'package:project/datClassToDoList.dart';
// import 'package:project/dataclass.dart';
import 'package:project/dbServices.dart';
import 'package:project/detdataTDL.dart';

import 'addDataTDL.dart';

class addData extends StatefulWidget {
  //untuk data yang dikirim dari halaman main
  int lastItem = 0;
  int lastProject = 0;
  addData({Key? key, required this.lastItem, required this.lastProject})
      : super(key: key);

  @override
  State<addData> createState() => _addDataState();
}

class _addDataState extends State<addData> {
  bool b = false;
  final _ctrId = TextEditingController();
  final _ctrNama = TextEditingController();
  @override
  void dispose() {
    // TODO: implement dispose
    _ctrId.dispose();
    _ctrNama.dispose();
    super.dispose();
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          title: Text('Detail Data Note'),
        ),
        body: Container(
          margin: EdgeInsets.all(16.0),
          child: Column(
            children: [
              Text(
                "Add Data Project",
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 25,
                    fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 20),
              TextField(
                controller: _ctrNama,
                enabled: true,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Nama Project',
                  labelStyle: TextStyle(
                      color: Colors.orange[500],
                      fontWeight: FontWeight.bold,
                      fontSize: 25),
                  filled: true,
                  fillColor: Color.fromARGB(255, 92, 92, 92),
                ),
                style: TextStyle(fontSize: 20, color: Colors.white),
              ),
              SizedBox(
                height: 20.0,
              ),
              Text(
                "To Do List",
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 25,
                    fontWeight: FontWeight.bold),
              ),
              Builder(
                builder: (context) {
                  return ElevatedButton(
                    onPressed: () {
                      // buttonPressed("=");
                      // listHistory.add(hasil_akhir.toString());
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) {
                            return addDataDTL(
                                idProject: widget.lastProject + 1,
                                lastItem: widget.lastItem);
                          },
                        ),
                      );
                      widget.lastItem++;
                    },
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.add),
                        Text("TDL"),
                      ],
                    ),
                    style: ElevatedButton.styleFrom(
                      primary: Colors.orange,
                      onPrimary: Colors.white,
                      textStyle: TextStyle(
                          color: Colors.black,
                          fontSize: 20,
                          fontStyle: FontStyle.italic),
                    ),
                  );
                },
              ),
              Container(
                // color: Color.accents,
                child: Expanded(
                  child: StreamBuilder<QuerySnapshot>(
                    stream: DatabaseToDoList.getDataTDLProject(_ctrId.text),

                    // stream: onSearchTDL(),
                    builder: (context, snapshot) {
                      if (snapshot.hasError) {
                        return const Text('ERROR');
                      } else if (snapshot.hasData || snapshot.data != null) {
                        if (snapshot.data!.docs.length != 0) {
                          //print(snapshot.data!.docs.length);

                          return ListView.separated(
                            itemBuilder: (context, index) {
                              if (snapshot.data!.docs[index]['idProject'] ==
                                  (widget.lastProject + 1).toString()) {
                                b = true;
                                DocumentSnapshot dsData =
                                    snapshot.data!.docs[index];
                                String lvIdProject = dsData['idProject'];
                                String lvIdTDL = dsData['idToDoList'];
                                String lvNamaTDL = dsData['namaToDoList'];
                                String lvStartDate = dsData['startDate'];
                                String lvEndDate = dsData['endDate'];
                                String lvStatus = dsData['status'];
                                // _jumlah = snapshot.data!.docs.length;

                                return ListTile(
                                  title: Text(
                                    "ID Project : " + lvIdProject,
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 15,
                                        color: Colors.white),
                                  ),
                                  subtitle: Column(
                                    children: [
                                      Row(
                                        children: [
                                          Text(
                                            lvNamaTDL,
                                            style: TextStyle(
                                                fontSize: 20,
                                                color: Colors.white),
                                          ),
                                        ],
                                      ),
                                      const Divider(
                                        thickness: 1,
                                        color: Colors.red,
                                      ),
                                    ],
                                  ),
                                  onTap: () {
                                    final dtTDL = itemToDoList(
                                        itemIdTDL: lvIdTDL,
                                        itemIdPTDL: lvIdProject,
                                        itemNamaTDL: lvNamaTDL,
                                        itemStartDateTDL: lvStartDate,
                                        itemEndDateTDL: lvEndDate,
                                        itemStatus: lvStatus);
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => detDataDTL(
                                                dataDetDTL: dtTDL,
                                                statusDataDetDTL: "isi",
                                              )),
                                    );
                                  },
                                  onLongPress: () {
                                    DatabaseToDoList.hapusData(idPTL: lvIdTDL);
                                  },
                                );
                              }
                              //mengambil data perindex ke dalam variabel dsData (read data)
                              else {
                                return SizedBox.shrink();
                              }
                            },
                            separatorBuilder: (context, index) =>
                                SizedBox(height: 8.0),
                            itemCount: snapshot.data!.docs.length,
                          );
                        } else {
                          //print(snapshot.data!.docs.length);
                        }
                      }
                      return const Center(
                        child: CircularProgressIndicator(
                          valueColor: AlwaysStoppedAnimation<Color>(
                            Colors.pinkAccent,
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
              SizedBox(
                height: 8.0,
              ),
              Container(
                alignment: Alignment.center,
                child: ElevatedButton(
                  onPressed: Navigator.of(context).pop,
                  child: Text("BACK"),
                ),
              ),
              ElevatedButton(
                onPressed: () {
                  if (b == true) {
                    final dt = itemProject(
                        itemIdProject: (widget.lastProject + 1).toString(),
                        itemNamaProject: _ctrNama.text,
                        itemStatusProject: "belum");
                    DatabaseProject.tambahDataProject(item: dt);
                    ScaffoldMessenger.of(context).showSnackBar(
                      //snackbar digunakan untuk memunculkan notif pada saat dipencet isi dari listviewnya
                      SnackBar(
                        //indexnya dari itemBuilder atas itu
                        content: Text("Project Added Successfully"),
                      ),
                    );
                    Navigator.pop(context);
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      //snackbar digunakan untuk memunculkan notif pada saat dipencet isi dari listviewnya
                      SnackBar(
                        //indexnya dari itemBuilder atas itu
                        content: Text(
                            "Project should at least have one To Do List!"),
                      ),
                    );
                  }
                },
                child: Text('Simpan Data'),
              ),
            ],
          ),
        ));
  }
}
